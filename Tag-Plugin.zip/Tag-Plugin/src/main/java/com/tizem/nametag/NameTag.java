package com.tizem.nametag;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class NameTag extends JavaPlugin implements Listener {

    private Economy econ;
    private FileConfiguration cfg;
    private BukkitTask tickTask;

    // playerUUID -> [tagStand, moneyStand]
    private final Map<UUID, ArmorStand[]> stands = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        cfg = getConfig();

        if (!setupEconomy()) {
            getLogger().severe("Vault + an economy plugin (e.g. EssentialsX) not found. Disabling.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        getServer().getPluginManager().registerEvents(this, this);

        for (Player p : Bukkit.getOnlinePlayers()) {
            spawnTags(p);
        }

        tickTask = Bukkit.getScheduler().runTaskTimer(this, this::tickAll, 5L, cfg.getLong("update-interval-ticks", 10L));

        getLogger().info("NameTag enabled.");
    }

    @Override
    public void onDisable() {
        if (tickTask != null) tickTask.cancel();
        for (ArmorStand[] pair : stands.values()) {
            for (ArmorStand a : pair) {
                if (a != null && !a.isDead()) a.remove();
            }
        }
        stands.clear();
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        econ = rsp.getProvider();
        return econ != null;
    }

    // ---------------- events ----------------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        spawnTags(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        removeTags(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onTeleport(PlayerTeleportEvent e) {
        // snap to new position immediately instead of waiting for next tick
        Bukkit.getScheduler().runTask(this, () -> updatePosition(e.getPlayer()));
    }

    // ---------------- core ----------------

    private void spawnTags(Player p) {
        removeTags(p); // safety: clear any stale entry first

        Location base = p.getLocation();

        ArmorStand tagStand = createStand(base);
        ArmorStand moneyStand = createStand(base);

        stands.put(p.getUniqueId(), new ArmorStand[]{tagStand, moneyStand});
        updateText(p);
        updatePosition(p);
    }

    private ArmorStand createStand(Location loc) {
        ArmorStand a = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityTypeSafe());
        a.setVisible(false);
        a.setGravity(false);
        a.setMarker(true);
        a.setSmall(true);
        a.setCustomNameVisible(true);
        a.setInvulnerable(true);
        a.setCollidable(false);
        a.setPersistent(false);
        a.setBasePlate(false);
        a.setArms(false);
        return a;
    }

    private org.bukkit.entity.EntityType EntityTypeSafe() {
        return org.bukkit.entity.EntityType.ARMOR_STAND;
    }

    private void removeTags(Player p) {
        ArmorStand[] pair = stands.remove(p.getUniqueId());
        if (pair == null) return;
        for (ArmorStand a : pair) {
            if (a != null && !a.isDead()) a.remove();
        }
    }

    private void tickAll() {
        if (econ == null) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!stands.containsKey(p.getUniqueId())) {
                spawnTags(p);
                continue;
            }
            updatePosition(p);
            updateText(p);
        }
    }

    private void updatePosition(Player p) {
        ArmorStand[] pair = stands.get(p.getUniqueId());
        if (pair == null) return;

        Location loc = p.getLocation().clone();
        double tagHeight = cfg.getDouble("tag-height", 2.5);
        double gap = cfg.getDouble("line-gap", 0.28);

        Location tagLoc = loc.clone().add(0, tagHeight, 0);
        Location moneyLoc = loc.clone().add(0, tagHeight - gap, 0);

        for (int i = 0; i < pair.length; i++) {
            ArmorStand a = pair[i];
            if (a == null || a.isDead()) continue;
            Location target = (i == 0) ? tagLoc : moneyLoc;
            if (a.getWorld().equals(target.getWorld())) {
                a.teleport(target);
            } else {
                // world changed: respawn in new world
                a.remove();
                ArmorStand fresh = createStand(target);
                pair[i] = fresh;
            }
        }
    }

    private void updateText(Player p) {
        ArmorStand[] pair = stands.get(p.getUniqueId());
        if (pair == null) return;

        String tagFormat = cfg.getString("tag-format", "&#55ffffCUSTOM TAG");
        String moneyFormat = cfg.getString("money-format", "&#ffff55$%amount%");

        String tagText = color(applyPlaceholders(tagFormat, p));
        String moneyText = color(applyPlaceholders(moneyFormat, p));

        if (pair[0] != null && !pair[0].isDead()) pair[0].setCustomName(tagText);
        if (pair[1] != null && !pair[1].isDead()) pair[1].setCustomName(moneyText);
    }

    private String applyPlaceholders(String s, Player p) {
        double balance = econ != null ? econ.getBalance(p) : 0.0;
        String formatted = formatMoney(balance);
        return s.replace("%amount%", formatted)
                .replace("%player%", p.getName());
    }

    private String formatMoney(double amount) {
        if (cfg.getBoolean("abbreviate", true)) {
            if (amount >= 1_000_000_000) return trim(amount / 1_000_000_000) + "B";
            if (amount >= 1_000_000) return trim(amount / 1_000_000) + "M";
            if (amount >= 1_000) return trim(amount / 1_000) + "K";
        }
        return String.format("%,.2f", amount);
    }

    private String trim(double v) {
        String s = String.format("%.1f", v);
        return s.endsWith(".0") ? s.substring(0, s.length() - 2) : s;
    }

    // Minimal hex color code translator: &#rrggbb + legacy &codes
    private String color(String input) {
        if (input == null) return "";
        StringBuilder result = new StringBuilder();
        int i = 0;
        while (i < input.length()) {
            if (input.charAt(i) == '&' && i + 7 < input.length() && input.charAt(i + 1) == '#') {
                String hex = input.substring(i + 2, i + 8);
                if (hex.matches("[0-9a-fA-F]{6}")) {
                    StringBuilder magic = new StringBuilder("§x");
                    for (char c : hex.toCharArray()) {
                        magic.append('§').append(c);
                    }
                    result.append(magic);
                    i += 8;
                    continue;
                }
            }
            if (input.charAt(i) == '&' && i + 1 < input.length()) {
                result.append('§').append(input.charAt(i + 1));
                i += 2;
                continue;
            }
            result.append(input.charAt(i));
            i++;
        }
        return result.toString();
    }

    // ---------------- command: reload ----------------

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("nametag")) {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                reloadConfig();
                cfg = getConfig();
                for (Player p : Bukkit.getOnlinePlayers()) updateText(p);
                sender.sendMessage("§aNameTag config reloaded.");
                return true;
            }
            sender.sendMessage("§7/nametag reload");
            return true;
        }
        return false;
    }
}
